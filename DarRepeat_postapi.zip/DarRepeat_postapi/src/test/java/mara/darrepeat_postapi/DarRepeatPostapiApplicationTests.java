package mara.darrepeat_postapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarRepeatPostapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
