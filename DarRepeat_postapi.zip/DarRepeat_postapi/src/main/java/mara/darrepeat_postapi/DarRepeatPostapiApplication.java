package mara.darrepeat_postapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarRepeatPostapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(DarRepeatPostapiApplication.class, args);
        System.out.println("dar");
    }

}
