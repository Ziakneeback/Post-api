package mara.darrepeat_postapi.controller;

import jakarta.validation.Valid;
import mara.darrepeat_postapi.model.PostModel;
import mara.darrepeat_postapi.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/post-core-api")


public class PostController {




    @Autowired
    private PostService postService;

    @Autowired
    Environment env;

    @GetMapping("/check")
    public String check() {
        return "Ur post-core-api is working at " + env.getProperty("local.server.port");
    }


    @PostMapping("/postSend")
    public ResponseEntity<String> sendPost(@Valid @RequestBody PostModel postModel) {
        postService.sendPost(postModel);
        return new ResponseEntity<String>("Ur post send", HttpStatus.OK);

    }

    @GetMapping("/all")
    public List<PostModel> allPost() {
        return postService.getallPost();
    }


    @GetMapping()
    public PostModel getPostById(@RequestParam String postId) {
        return postService.getPostById(postId);
    }

    @GetMapping("/{postId}")
    public PostModel getPostById2(@PathVariable String postId) {
        return postService.getPostById(postId);
    }

    @PutMapping("/{postId}")
    public ResponseEntity<String> updatePost(@PathVariable String postId,
                                             @Valid @RequestBody PostModel postModel) {
        postService.updatePostById(postId, postModel);
        return new ResponseEntity<String>("ur post updated", HttpStatus.OK);
    }

    @DeleteMapping("/{postId}")
    public ResponseEntity<String> deletePostById(@PathVariable String postId) {
        postService.deletePOsstById(postId);
        return new ResponseEntity<String>("ur delete this posst", HttpStatus.OK);
    }


}
