package mara.darrepeat_postapi.service;


import mara.darrepeat_postapi.model.PostModel;

import java.util.List;

public interface PostService {

    void sendPost(PostModel postModel);

    List<PostModel> getallPost();

    PostModel getPostById(String postId);

    PostModel getPostById2(String postId);

    void updatePostById(String postId, PostModel postModel);

    void deletePOsstById(String postId);





}
