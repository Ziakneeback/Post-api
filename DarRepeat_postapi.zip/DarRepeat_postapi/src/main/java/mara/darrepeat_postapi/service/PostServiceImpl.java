package mara.darrepeat_postapi.service;


import mara.darrepeat_postapi.model.PostModel;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

@Service
public class PostServiceImpl implements PostService{

    HashMap<String, PostModel> postModelHashMap = new HashMap<>();
    {
        PostModel postModel = new PostModel(UUID.randomUUID().toString(),"vape",
                UUID.randomUUID().toString(),"Marlen",UUID.randomUUID().toString(),"Izim",
                "delivered"
                );
        postModelHashMap.put(postModel.getPostId(),postModel);


    }

    @Override
    public void sendPost(PostModel postModel) {
        if(postModel.getPostId()==null){
            postModel.setPostId(UUID.randomUUID().toString());
        }
        if(postModel.getClientId()==null){
            postModel.setPostId(UUID.randomUUID().toString());
        }
        if(postModel.getPostRecipientId()==null){
            postModel.setPostId(UUID.randomUUID().toString());
        }
        postModelHashMap.put(postModel.getPostId(), postModel);
    }

    @Override
    public List<PostModel> getallPost() {
        return postModelHashMap.values().stream().toList();
    }

    @Override
    public PostModel getPostById(String postId) {
        return postModelHashMap.get(postId);
    }

    @Override
    public PostModel getPostById2(String postId) {
        return postModelHashMap.get(postId);
    }

    @Override
    public void updatePostById(String postId, PostModel postModel) {
         postModel.setPostId(postId);
         postModelHashMap.put(postModel.getPostId(), postModel);
    }

    @Override
    public void deletePOsstById(String postId) {
        postModelHashMap.remove(postId);
    }
}
