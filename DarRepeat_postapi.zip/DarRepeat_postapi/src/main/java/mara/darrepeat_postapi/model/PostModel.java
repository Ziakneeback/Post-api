package mara.darrepeat_postapi.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor


public class PostModel {
    @NotNull(message = "id of ur post cant be empty")
    private String PostId;
    @NotNull(message = "please what is ur post")
    private String postItem;
    @NotNull(message = "id of ur client cant be empty")
    private String clientId;
    private String clientName;
    @NotNull(message = "id of client who get post cant be empty")
    private String postRecipientId;
    private String RecipientName;
    private String status;

}
